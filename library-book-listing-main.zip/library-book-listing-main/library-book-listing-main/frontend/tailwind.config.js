module.exports = {
  purge: ["./src/**/*.html", "./src/**/*.js"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      colors: {
        pink: {
          light: "#d4484a",
          DEFAULT: "#d4484a",
          dark: "#d4484a",
        },
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
