const CONSTANTS = {};

CONSTANTS.BASEURL = "http://localhost:8088/api";

module.exports = CONSTANTS;
