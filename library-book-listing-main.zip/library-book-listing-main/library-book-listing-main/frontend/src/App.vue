<template>
  <div id="app" class="h-screen flex">
    <sidebar />
    <main
      class="flex-1 bg-gray-200 dark:bg-gray-900 overflow-y-auto transition duration-500 ease-in-out"
    >
      <div class="px-3 py-2  transition duration-500 ease-in-out">
        <!-- <top-navbar /> -->

        <div
          class="border dark:border-gray-700 transition duration-500
				ease-in-out"
        ></div>
        <div class="flex flex-col mt-2">
          <router-view />
        </div>
      </div>
    </main>
  </div>
</template>

<script>
  import Sidebar from "./components/layouts/Sidebar.vue";
  // import TopNavbar from "./components/layouts/TopNavbar";
  import { mapState, mapActions } from "vuex";

  export default {
    components: { Sidebar },
    methods: {
      ...mapActions(["loadAllBooks"]),
    },
    created() {
      this.loadAllBooks();
    },
  };
</script>

<style lang="scss">
  #app {
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  #nav {
    padding: 30px;
    a {
      font-weight: bold;
      color: #2c3e50;
      &.router-link-exact-active {
        color: #42b983;
      }
    }
  }
</style>
