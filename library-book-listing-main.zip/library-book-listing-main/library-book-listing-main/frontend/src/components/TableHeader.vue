<template>
  <div
    class="flex flex-col lg:flex-row p-4 lg:p-8 justify-between items-start lg:items-stretch w-full"
  >
    <div class="w-full lg:w-1/3 flex flex-col lg:flex-row items-start lg:items-center">
      <div class="flex items-center">
        <a
          class="text-gray-600 dark:text-gray-400 p-2 border-transparent border bg-gray-100 dark:hover:bg-gray-600 dark:bg-gray-700 hover:bg-gray-200 cursor-pointer rounded focus:outline-none focus:border-gray-800 focus:shadow-outline-gray"
          href="javascript: void(0)"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            @click="dropdownFunction"
            class="icon icon-tabler icon-tabler-dots-vertical dropbtn"
            width="28"
            height="28"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" />
            <circle cx="12" cy="12" r="1" />
            <circle cx="12" cy="19" r="1" />
            <circle cx="12" cy="5" r="1" />
          </svg>
        </a>
        <a
          class="text-gray-600 dark:text-gray-400 mx-2 p-2 border-transparent border bg-gray-100 dark:hover:bg-gray-600 dark:bg-gray-700 hover:bg-gray-200 cursor-pointer rounded focus:outline-none focus:border-gray-800 focus:shadow-outline-gray"
          href="javascript: void(0)"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="icon cursor-pointer icon-tabler icon-tabler-settings"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" />
            <path
              d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
            />
            <circle cx="12" cy="12" r="3" />
          </svg>
        </a>
      </div>
    </div>
    <div class="w-full lg:w-2/3 flex flex-col lg:flex-row items-start lg:items-center justify-end">
      <div class="flex items-center lg:border-r border-gray-300 pb-3 lg:pb-0 lg:px-6">
        <div class="relative w-32 z-10">
          <div
            class="pointer-events-none text-gray-600 dark:text-gray-400 absolute inset-0 m-auto mr-2 xl:mr-4 z-0 w-5 h-5"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="icon cursor-pointer icon-tabler icon-tabler-chevron-down"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              fill="none"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path stroke="none" d="M0 0h24v24H0z"></path>
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>

          <select
            @change="changeViewMode(viewMode)"
            v-model="viewMode"
            aria-label="Selected tab"
            class="focus:outline-none border border-transparent focus:border-gray-800 focus:shadow-outline-gray text-base form-select block w-full py-2 px-2 xl:px-3 rounded text-gray-600 dark:text-gray-400 appearance-none bg-transparent"
          >
            <option value="list-view">List View</option>
            <option value="grid-view">Grid View</option>
          </select>
        </div>
      </div>

      <div class="lg:ml-6 flex items-center">
        <div
          @click="onAddNewBook"
          class="text-white ml-4 cursor-pointer focus:outline-none border border-transparent focus:border-gray-800 focus:shadow-outline-gray bg-indigo-700 transition duration-150 ease-in-out hover:bg-indigo-600 w-8 h-8 rounded flex items-center justify-center"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="icon icon-tabler icon-tabler-plus"
            width="28"
            height="28"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" />
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapActions } from "vuex";
  export default {
    data() {
      return {
        viewMode: "list-view",
      };
    },
    methods: {
      onAddNewBook() {
        this.$router.push({ name: "create-book" });
      },
      dropdownFunction(e) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        let list = event.currentTarget.parentElement.parentElement.getElementsByClassName(
          "dropdown-content"
        )[0];
        for (i = 0; i < dropdowns.length; i++) {
          dropdowns[i].classList.add("hidden");
        }
        list.classList.toggle("hidden");
      },
      ...mapActions(["changeViewMode"]),
    },
  };
</script>

<style></style>
