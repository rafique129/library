<template>
  <!-- component -->
  <!-- This is an example component -->
  <div class="flex flex-col">
    <div>
      <button
        v-if="status"
        type="button"
        class="rounded-full px-4 mr-2 bg-red-400 text-white p-2   leading-none flex items-center"
      >
        Sold out
      </button>
      <button
        v-else
        type="button"
        class="rounded-full px-4 mr-2 bg-green-400 text-white p-2   leading-none flex items-center"
      >
        Available
      </button>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      status: {
        type: Number,
        require: true,
      },
    },
  };
</script>

<style></style>
