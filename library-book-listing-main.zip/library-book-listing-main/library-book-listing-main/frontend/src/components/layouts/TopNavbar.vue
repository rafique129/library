<template>
  <div class="mt-1 p-3 mb-4 bg-white flex items-center justify-between">
    <div class="flex items-center select-none">
      <button
        class="ml-2 bg-gray-200 dark:bg-gray-600
						dark:text-gray-200 rounded-full p-2 focus:outline-none
						hover:text-pink-500 hover:bg-pink-300 transition
						duration-500 ease-in-out"
      >
        <svg class="h-5 w-5 fill-current" viewBox="0 0 24 24">
          <path
            d="M12 4a4 4 0 014 4 4 4 0 01-4 4 4 4 0 01-4-4 4
								4 0 014-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21
								3.58-4 8-4z"
          ></path>
        </svg>
      </button>
    </div>

    <div class="flex items-center select-none">
      <button
        class="ml-2 bg-gray-200 dark:bg-gray-600
						dark:text-gray-200 rounded-full p-2 focus:outline-none
						hover:text-pink-500 hover:bg-pink-300 transition
						duration-500 ease-in-out"
      >
        <svg class="h-5 w-5 fill-current" viewBox="0 0 24 24">
          <path
            d="M12 4a4 4 0 014 4 4 4 0 01-4 4 4 4 0 01-4-4 4
								4 0 014-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21
								3.58-4 8-4z"
          ></path>
        </svg>
      </button>
      <button
        class="ml-2 bg-gray-200 dark:bg-gray-600
						dark:text-gray-200 rounded-full p-2 focus:outline-none
						hover:text-pink-500 hover:bg-pink-300 transition
						duration-500 ease-in-out"
      >
        <svg class="h-5 w-5 fill-current" viewBox="0 0 24 24">
          <path
            d="M12 4a4 4 0 014 4 4 4 0 01-4 4 4 4 0 01-4-4 4
								4 0 014-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21
								3.58-4 8-4z"
          ></path>
        </svg>
      </button>
    </div>
  </div>
</template>

<script>
  export default {};
</script>

<style></style>
