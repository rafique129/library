<template>
  <div>
    <div class="w-full overflow-x-scroll xl:overflow-x-hidden">
      <table class="min-w-full bg-white dark:bg-gray-800">
        <thead>
          <tr class="w-full h-16 border-gray-300 border-b py-8">
            <th
              class="pl-8 text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              SN#
            </th>

            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              Cover Photo
            </th>
            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              Title
            </th>
            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              Author
            </th>
            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              ISBN Number
            </th>
            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              Published Year
            </th>
            <th
              class="text-gray-600 dark:text-gray-400 font-normal pr-6 text-left text-sm tracking-normal leading-4"
            >
              Available
            </th>

            <td
              class="text-gray-600 dark:text-gray-400 font-normal pr-8 text-center text-sm tracking-normal leading-4"
            >
              More
            </td>
          </tr>
        </thead>

        <tbody v-if="isDataLoading">
          <tr class="flex flex-row">
            <td
              colspan="7"
              class="text-gray-600 dark:text-gray-400 font-normal pr-8 text-center text-sm tracking-normal leading-4"
            >
              <div
                wire:loading
                class="fixed top-0 left-0 right-0 bottom-0 w-full h-screen z-50 overflow-hidden bg-gray-700 opacity-75 flex flex-col items-center justify-center"
              >
                <div
                  class="loader ease-linear rounded-full border-4 border-t-4 border-gray-200 h-12 w-12 mb-4"
                ></div>
                <h2 class="text-center text-white text-xl font-semibold">Loading...</h2>
                <p class="w-1/3 text-center text-white">
                  This may take a few seconds, please don't close this page.
                </p>
              </div>

              <button>hey</button>
            </td>
          </tr>
        </tbody>

        <tbody v-if="isDataLoaded">
          <tr
            class="h-24 border-gray-300 border-b"
            v-for="(book, index) in this.books"
            :key="book.id"
          >
            <td
              class="pl-8 pr-6 text-left whitespace-no-wrap text-sm text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              {{ index + 1 }}
            </td>

            <td class="pr-2 whitespace-no-wrap">
              <table-cover-photo :photo="book.cover_photo" />
            </td>

            <td
              class="text-sm pr-6 text-left whitespace-no-wrap text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              {{ book.title }}
            </td>
            <td
              class="text-sm text-left pr-6 whitespace-no-wrap text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              {{ book.author }}
            </td>

            <td
              class="text-sm text-left pr-6 whitespace-no-wrap text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              {{ book.isbn_number }}
            </td>
            <td
              class="text-sm text-left pr-6 whitespace-no-wrap text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              {{ book.published_year }}
            </td>
            <td
              class="text-sm text-left pr-6 whitespace-no-wrap text-gray-800 dark:text-gray-100 tracking-normal leading-4"
            >
              <book-selling-status-badge :status="book.is_sold" />
            </td>

            <td class="pr-8 relative ">
              <table-more-action :index="index" :status="book.is_sold" />
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- <table-footer v-on:change-page-view="pageView(true)" /> -->
  </div>
</template>

<script>
  import { mapState, mapActions } from "vuex";

  import TableFooter from "../components/TableFooter.vue";
  import TableMoreAction from "../components/TableMoreAction.vue";
  import TableCoverPhoto from "../components/TableCoverPhoto.vue";
  import BookSellingStatusBadge from "../components/BookSellingStatusBadge.vue";
  export default {
    components: {
      TableMoreAction,
      TableCoverPhoto,
      BookSellingStatusBadge,
    },
    name: "CompactTableWithActionsAndSelect",
    data() {
      return {
        temp: 0,
      };
    },
    methods: {
      documentClick(event) {
        if (!event.target.matches(".dropbtn")) {
          var dropdowns = document.getElementsByClassName("dropdown-content");
          var i;
          for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            openDropdown.classList.add("hidden");
          }
        }
      },

      pageView(val) {
        let text = document.getElementById("page-view");
        if (val) {
          if (this.$data.temp === 2) {
            this.$data.temp = 0;
          } else {
            this.$data.temp = this.$data.temp + 1;
          }
        } else if (this.$data.temp !== 0) {
          this.$data.temp = this.$data.temp - 1;
        }
        switch (this.$data.temp) {
          case 0:
            text.innerHTML = "Viewing 1 - 20 of 60";
            break;
          case 1:
            text.innerHTML = "Viewing 21 - 40 of 60";
            break;
          case 2:
            text.innerHTML = "Viewing 41 - 60 of 60";
        }
      },
    },
    computed: {
      ...mapState(["isDataLoading", "books", "isDataLoaded"]),
    },
    created() {
      document.addEventListener("click", this.documentClick);
    },
    unmounted() {
      document.removeEventListener("click", this.documentClick);
    },
  };
</script>
<style scoped>
  .loader {
    border-top-color: #3498db;
    -webkit-animation: spinner 1.5s linear infinite;
    animation: spinner 1.5s linear infinite;
  }

  @-webkit-keyframes spinner {
    0% {
      -webkit-transform: rotate(0deg);
    }
    100% {
      -webkit-transform: rotate(360deg);
    }
  }

  @keyframes spinner {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
</style>
