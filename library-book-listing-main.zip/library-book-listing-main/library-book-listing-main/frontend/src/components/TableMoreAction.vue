<template>
  <div>
    <div class="dropdown-content mt-8 absolute left-0 -ml-12 shadow-md z-10 hidden w-32">
      <ul class="bg-white dark:bg-gray-800 shadow rounded py-1">
        <li
          @click="onEditBook"
          class="cursor-pointer text-gray-600 dark:text-gray-400 text-sm leading-3 tracking-normal py-3 hover:bg-indigo-700 hover:text-white px-3 font-normal"
        >
          Edit
        </li>
        <li
          @click="onShowBook"
          class="cursor-pointer text-gray-600 dark:text-gray-400 text-sm leading-3 tracking-normal py-3 hover:bg-indigo-700 hover:text-white px-3 font-normal"
        >
          Show Details
        </li>
        <li
          @click="deleteBook(index)"
          class="cursor-pointer text-red-500 dark:text-gray-400 text-sm leading-3 tracking-normal py-3 hover:bg-indigo-700 hover:text-white px-3 font-normal"
        >
          Delete
        </li>
        <li
          @click="updateSellStatus(index)"
          v-if="!status"
          class="cursor-pointer text-red-500 dark:text-gray-400 text-sm leading-3 tracking-normal py-3 hover:bg-indigo-700 hover:text-white px-3 font-normal"
        >
          Mark As Sold
        </li>
        <li
          @click="updateSellStatus(index)"
          v-else
          class="cursor-pointer text-green-500 dark:text-gray-400 text-sm leading-3 tracking-normal py-3 hover:bg-indigo-700 hover:text-white px-3 font-normal"
        >
          Available
        </li>
      </ul>
    </div>
    <button
      class="text-gray-500 p-2 rounded cursor-pointer border border-transparent focus:outline-none"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        @click="dropdownFunction"
        class="icon icon-tabler icon-tabler-dots-vertical dropbtn"
        width="28"
        height="28"
        viewBox="0 0 24 24"
        stroke-width="1.5"
        stroke="currentColor"
        fill="none"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path stroke="none" d="M0 0h24v24H0z" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="12" cy="19" r="1" />
        <circle cx="12" cy="5" r="1" />
      </svg>
    </button>
  </div>
</template>

<script>
  import { mapState, mapActions } from "vuex";

  export default {
    props: {
      status: {
        type: Number,
        require: true,
      },
      index: {
        type: Number,
        require: true,
      },
    },
    methods: {
      dropdownFunction(e) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        let list = e.currentTarget.parentElement.parentElement.getElementsByClassName(
          "dropdown-content"
        )[0];
        for (i = 0; i < dropdowns.length; i++) {
          dropdowns[i].classList.add("hidden");
        }
        list.classList.toggle("hidden");
      },
      onEditBook() {
        const bookId = this.books[this.index].id;
        this.$router.push({ name: "edit-book", params: { id: bookId } });
      },
      onShowBook() {
        const bookId = this.books[this.index].id;
        this.$router.push({ name: "show-book", params: { id: bookId } });
      },
      ...mapActions(["deleteBook", "updateSellStatus"]),
    },
    computed: {
      ...mapState(["books"]),
    },
  };
</script>

<style></style>
