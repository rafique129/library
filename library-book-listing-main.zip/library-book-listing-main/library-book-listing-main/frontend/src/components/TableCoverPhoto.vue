<template>
  <div class="flex items-center">
    <div class="h-20 w-20">
      <img :src="photo" alt="photo" class="h-full w-full overflow-hidden shadow" />
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      photo: {
        type: String,
        require: true,
      },
    },
  };
</script>

<style></style>
