<template>
  <div>
    <div
      class="p-10 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-3 gap-5"
    >
      <div v-for="book in books" :key="book.id">
        <div class="flex max-w-md bg-white shadow-lg rounded-lg overflow-hidden">
          <div
            class="w-1/3 bg-contain"
            :style="`background-image: url('${book.cover_photo}')`"
          ></div>
          <div class="w-2/3 p-4 h-48">
            <h1 class="text-gray-900 font-bold text-2xl text-left">{{ book.title }}</h1>
            <p class="text-green-700 font-bold text-sm text-left">{{ book.author }}</p>
            <hr />
            <p class="mt-2 text-gray-600 text-sm text-left">
              {{ book.description.substring(0, 100) }}...
            </p>
            <div class="flex item-center justify-between mt-3">
              <p v-if="book.is_sold" class="text-red-700 font-bold text-sm">Sold Out</p>
              <p v-else class="text-green-700 font-bold text-sm">Available</p>
              <button
                @click="onShowBook(book.id)"
                class="px-3 py-2 bg-gray-800 text-white text-xs font-bold uppercase rounded"
              >
                Show Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapState } from "vuex";
  export default {
    methods: {
      onShowBook(bookId) {
        this.$router.push({ name: "show-book", params: { id: bookId } });
      },
    },
    computed: { ...mapState(["books"]) },
  };
</script>

<style></style>
