<template>
  <div
    class="flex flex-col lg:flex-row p-4 lg:p-8 justify-between items-start lg:items-stretch w-full"
  >
    <div class="w-full lg:w-3/3 flex flex-col lg:flex-row items-start lg:items-center justify-end">
      <div class="flex items-center lg:border-l lg:border-r border-gray-300 py-3 lg:py-0 lg:px-6">
        <p class="text-base text-gray-600 dark:text-gray-400" id="page-view">
          Viewing 1 - 20 of 60
        </p>
        <a
          class="text-gray-600 dark:text-gray-400 ml-2 border-transparent border cursor-pointer rounded"
          @click="$emit('change-page-view')"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="icon icon-tabler icon-tabler-chevron-left"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" />
            <polyline points="15 6 9 12 15 18" />
          </svg>
        </a>
        <a
          class="text-gray-600 dark:text-gray-400 border-transparent border rounded focus:outline-none cursor-pointer"
          @click="$emit('change-page-view')"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="icon icon-tabler icon-tabler-chevron-right"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path stroke="none" d="M0 0h24v24H0z" />
            <polyline points="9 6 15 12 9 18" />
          </svg>
        </a>
      </div>
    </div>
  </div>
</template>

<script>
  export default {};
</script>

<style></style>
