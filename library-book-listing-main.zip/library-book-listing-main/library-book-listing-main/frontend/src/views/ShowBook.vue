<template>
  <section class="text-gray-700 body-font overflow-hidden bg-white">
    <div class="container px-5 py-24 mx-auto">
      <div class="lg:w-4/5 mx-auto flex flex-wrap">
        <img
          alt="ecommerce"
          class=" w-64 h-50 object-cover object-center rounded border border-gray-200"
          :src="book.cover_photo"
        />
        <div class="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">
          <h2 class="text-sm title-font text-gray-500 tracking-widest text-left">
            <span class="text-red-500">Written By: </span>{{ book.author }}
          </h2>
          <h1 class="text-gray-900 text-3xl title-font font-medium mb-1 text-left">
            {{ book.title }}
          </h1>
          <hr class="p-3" />
          <p class="leading-relaxed  text-left">
            {{ book.description }}
          </p>
          <hr class="p-3" />
          <p class="leading-relaxed pb-3 text-left">
            <span class="text-red-500">ISBN Number: </span>{{ book.isbn_number }}
          </p>
          <p class="leading-relaxed pb-3 text-left">
            <span class="text-red-500">Code: </span>{{ book.code }}
          </p>
          <p class="leading-relaxed pb-3 text-left">
            <span class="text-red-500">Published: </span>{{ book.published_year }}
          </p>
          <div class="flex">
            <p
              v-if="book.is_sold"
              class="flex ml-auto text-white bg-red-500 border-0 py-2 px-6 focus:outline-none rounded"
            >
              Sold Out
            </p>

            <p
              v-else
              class="flex ml-auto text-white bg-green-500 border-0 py-2 px-6 focus:outline-none rounded"
            >
              Available
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
  import axios from "axios";
  import CONSTANTS from "../constants";
  import { mapState, mapActions } from "vuex";

  export default {
    data() {
      return {
        book: {},
        routeId: null,
      };
    },
    computed: {
      ...mapState(["books"]),
    },
    mounted() {
      this.routeId = this.$route.params.id;
      this.book = this.books.find((b) => b.id == this.routeId);
    },
  };
</script>

<style></style>
