<template>
  <div class="w-full bg-gray-200 ">
    <div class="mx-auto container bg-white dark:bg-gray-800 dark:bg-gray-800 shadow rounded">
      <table-header />

      <book-list-view v-if="listView" />

      <book-grid-view v-if="gridView" />
    </div>
  </div>
</template>

<script>
  import { mapState } from "vuex";

  import TableHeader from "../components/TableHeader.vue";
  import BookListView from "../components/BookListView.vue";
  import BookGridView from "../components/BookGridView.vue";
  export default {
    components: {
      TableHeader,
      BookListView,
      BookGridView,
    },
    name: "CompactTableWithActionsAndSelect",
    data() {
      return {
        temp: 0,
      };
    },
    methods: {
      documentClick(event) {
        if (!event.target.matches(".dropbtn")) {
          var dropdowns = document.getElementsByClassName("dropdown-content");
          var i;
          for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            openDropdown.classList.add("hidden");
          }
        }
      },
    },
    computed: {
      ...mapState(["isDataLoading", "books", "isDataLoaded", "listView", "gridView"]),
    },
    created() {
      document.addEventListener("click", this.documentClick);
    },
    unmounted() {
      document.removeEventListener("click", this.documentClick);
    },
  };
</script>
<style scoped>
  .loader {
    border-top-color: #3498db;
    -webkit-animation: spinner 1.5s linear infinite;
    animation: spinner 1.5s linear infinite;
  }

  @-webkit-keyframes spinner {
    0% {
      -webkit-transform: rotate(0deg);
    }
    100% {
      -webkit-transform: rotate(360deg);
    }
  }

  @keyframes spinner {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
</style>
