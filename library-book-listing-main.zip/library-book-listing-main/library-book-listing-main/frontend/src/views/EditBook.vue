<template>
  <div class="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
    <div class="relative py-3 sm:max-w-xl sm:mx-auto">
      <div class="relative px-4 py-10 bg-white mx-8 md:mx-0 shadow rounded-3xl sm:p-10">
        <div class="max-w-md mx-auto">
          <div class="flex items-center space-x-5">
            <div
              class="h-14 w-14 bg-red-300 rounded-full flex flex-shrink-0 justify-center items-center text-white-500 text-2xl font-mono"
            >
              i
            </div>
            <div class="block pl-2 font-semibold text-xl self-start text-gray-700">
              <h2 class="leading-relaxed">Edit Book</h2>
              <p class="text-sm text-gray-500 font-normal leading-relaxed">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit.
              </p>
            </div>
          </div>
          <div class="divide-y divide-gray-200">
            <div class="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
              <div class="flex flex-col">
                <label class="leading-loose text-left">Book Title</label>
                <input
                  type="text"
                  v-model="book.title"
                  class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                  placeholder="Book title"
                />
              </div>
              <div class="flex flex-col">
                <label class="leading-loose text-left">Book Author</label>
                <input
                  type="text"
                  v-model="book.author"
                  class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                  placeholder="Book Author"
                />
              </div>
              <div class="flex flex-col">
                <label class="leading-loose text-left">ISB Number</label>
                <input
                  type="number"
                  v-model="book.isbn_number"
                  class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                  placeholder="ISB Number"
                />
              </div>
              <div class="flex items-center space-x-4">
                <div class="flex flex-col">
                  <label class="leading-loose text-left">Code</label>
                  <div class="relative focus-within:text-gray-600 text-gray-400">
                    <input
                      type="number"
                      v-model="book.code"
                      class="pr-4 pl-10 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                      placeholder="Code"
                    />
                  </div>
                </div>
                <div class="flex flex-col">
                  <label class="leading-loose text-left">Published Year</label>
                  <div class="relative focus-within:text-gray-600 text-gray-400">
                    <input
                      v-model="book.published_year"
                      type="number"
                      class="pr-4 pl-10 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600"
                      placeholder="Year"
                    />
                  </div>
                </div>
              </div>
              <div class="flex flex-col">
                <label class="leading-loose text-left">Book Description</label>
                <textarea
                  v-model="book.description"
                  class="w-full px-3 py-2 text-gray-700 border rounded-lg focus:outline-none"
                  rows="4"
                ></textarea>
              </div>
            </div>
            <div class="pt-4 flex items-center space-x-4">
              <button
                @click="onCancel"
                class="flex justify-center items-center w-full text-gray-900 px-4 py-3 rounded-md focus:outline-none"
              >
                <svg
                  class="w-6 h-6 mr-3"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
                Cancel
              </button>
              <button
                @click="onSaveBook"
                class="bg-blue-500 flex justify-center items-center w-full text-white px-4 py-3 rounded-md focus:outline-none"
              >
                Update
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import CONSTANTS from "../constants";
  import { mapState, mapActions } from "vuex";

  export default {
    data() {
      return {
        book: {},
        routeId: null,
      };
    },
    methods: {
      onSaveBook() {
        const app = this;
        const url = `${CONSTANTS.BASEURL}/books/${app.routeId}`;

        if (app.book.title === null || app.book.title === "") alert("Book Title can't be empty");

        axios
          .patch(url, app.book)
          .then(function(response) {
            if (response.status === 200) {
              app.updateBook(response.data);
              app.$router.push({ name: "home" });
            }
          })
          .catch(function(error) {
            console.log(error);
          });
      },
      onCancel() {
        this.$router.push({ name: "home" });
      },
      ...mapActions(["updateBook"]),
    },
    computed: {
      ...mapState(["books"]),
    },
    mounted() {
      this.routeId = this.$route.params.id;
      this.book = this.books.find((b) => b.id == this.routeId);
    },
  };
</script>

<style></style>
