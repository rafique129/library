<template>
  <div class="about">
    <h1>This is an about page for vue-router demo</h1>
  </div>
</template>
