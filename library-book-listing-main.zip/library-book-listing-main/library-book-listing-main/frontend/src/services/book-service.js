import axios from "axios";
import CONSTANTS from "../constants";

export default class BookService {
  async loadAllData() {
    const url = `${CONSTANTS.BASEURL}/books`;

    const response = await axios.get(url);

    if (response.status === 200) return response.data;
  }

  async deleteBook(id) {
    const url = `${CONSTANTS.BASEURL}/books/${id}`;

    const response = await axios.delete(url);

    if (response.status === 200) return { message: response.data, status: response.status };
  }

  async updateSellStatus(id) {
    const url = `${CONSTANTS.BASEURL}/books/${id}/change-sell-status`;

    const response = await axios.patch(url);

    if (response.status === 200) return { book: response.data, status: response.status };
  }
}
