import Vue from "vue";
import Vuex from "vuex";
import BookService from "./services/book-service";

Vue.use(Vuex);

const service = new BookService();

export default new Vuex.Store({
  state: {
    isDataLoading: false,
    isDataLoaded: false,
    books: [],
    listView: true,
    gridView: false,
  },
  getters: {},
  mutations: {
    async LOAD_ALL_BOOKS(state, payload) {
      state.isDataLoading = true;
      try {
        const books = await service.loadAllData();
        state.books = books;
      } catch (error) {
        console.log(error);
      }
      state.isDataLoading = false;
      state.isDataLoaded = true;
    },
    async DELETE_BOOK(state, payload) {
      state.isDataLoading = true;
      try {
        const response = await service.deleteBook(state.books[payload].id);
        if (response.status === 200) state.books.splice(payload, 1);
      } catch (error) {
        console.log(error);
      }
      state.isDataLoading = false;
      state.isDataLoaded = true;
    },
    async UPDATE_SELL_STATUS(state, payload) {
      state.isDataLoading = true;
      try {
        const response = await service.updateSellStatus(state.books[payload].id);
        if (response.status === 200) {
          response.book.is_sold = response.book.is_sold ? 1 : 0;
          state.books[payload] = response.book;
        }
      } catch (error) {
        console.log(error);
      }
      state.isDataLoading = false;
      state.isDataLoaded = true;
    },
    ADD_NEW_BOOK(state, payload) {
      state.books.push(payload);
    },
    UPDATE_BOOK(state, payload) {
      const index = state.books.findIndex((b) => b.id == payload.id);
      state.books[index] = payload;
    },
    CHANGE_VIEW_MODE(state, payload) {
      if (payload === "list-view") {
        state.listView = true;
        state.gridView = false;
      }
      if (payload === "grid-view") {
        state.listView = false;
        state.gridView = true;
      }
    },
  },
  actions: {
    loadAllBooks(context, data) {
      context.commit("LOAD_ALL_BOOKS", data);
    },

    deleteBook(context, data) {
      context.commit("DELETE_BOOK", data);
    },

    updateSellStatus(context, data) {
      context.commit("UPDATE_SELL_STATUS", data);
    },
    addNewBook(context, data) {
      context.commit("ADD_NEW_BOOK", data);
    },
    updateBook(context, data) {
      context.commit("UPDATE_BOOK", data);
    },
    changeViewMode(context, data) {
      context.commit("CHANGE_VIEW_MODE", data);
    },
  },
});
