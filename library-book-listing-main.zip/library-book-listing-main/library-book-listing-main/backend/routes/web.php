<?php


$router->get('/', function () use ($router) {
    return $router->app->version();
});

// route group for 'api' prefix
$router->group(['prefix' => 'api'], function () use ($router) {

    // get all books
    $router->get('books', 'BookController@index');

    // create new book
    $router->post('books', 'BookController@store');

    // up date book
    $router->patch('books/{bookId}', 'BookController@update');

    // delete book
    $router->delete('books/{bookId}', 'BookController@destroy');

    // update book sell status
    $router->patch('books/{bookId}/change-sell-status', 'BookController@updateBookSellStatus');

    // upload book image
    $router->post('books/{bookId}/upload-cover-photo', 'BookController@uploadBookCoverPhoto');
});
