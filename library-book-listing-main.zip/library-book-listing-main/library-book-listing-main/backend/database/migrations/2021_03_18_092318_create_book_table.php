<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->id();
            $table->string('title', 256);
            $table->string('author', 256)->nullable();
            $table->string('isbn_number', 100)->nullable()->unique();
            $table->string('code', 100)->nullable()->unique();
            $table->string('published_year', 20)->nullable();
            $table->string('cover_photo', 256)->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_sold')->default(false);
            $table->boolean('is_available')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book');
    }
}
