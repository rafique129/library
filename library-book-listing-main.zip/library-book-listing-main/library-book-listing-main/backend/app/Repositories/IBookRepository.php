<?php

namespace App\Repositories;

use App\Models\Book;
use Illuminate\Http\Request;

interface IBookRepository
{
    public function getAllBooks();
    // public function getSingleBook();
    public function createNewBook(Request $request);
    public function updateBook(Request $request, Book $book);
    public function deleteBook(Book $book);
    public function updateBookSoldStatus(Book $book);
    public function uploadBookCoverPhoto(Request $request, Book $book);
}
