<?php

namespace App\Repositories;

use App\Models\Book;
use Exception;
use Illuminate\Http\Request;

class BookRepository implements IBookRepository
{

    public function getAllBooks()
    {
        return Book::ascending()->get();
    }

    public function createNewBook(Request $request)
    {
        $book = new Book();
        $book->title = $request->title;
        $book->author = $request->author;
        $book->code = $request->code;
        $book->isbn_number = $request->isbn_number;
        $book->published_year = $request->published_year;
        // $book->cover_photo = $request->cover_photo;
        $book->description = $request->description;

        $book->save();
        $book->cover_photo = url() . "/no_image.jpg";
        return $book;
    }

    public function updateBook(Request $request, Book $book)
    {
        $book->title = $request->title;
        $book->author = $request->author;
        $book->code = $request->code;
        $book->isbn_number = $request->isbn_number;
        $book->published_year = $request->published_year;
        // $book->cover_photo = $request->cover_photo;
        $book->description = $request->description;

        $book->update();

        return $book;
    }

    public function deleteBook(Book $book)
    {
        $book->delete();

        return ['message' => 'Book Deleted'];
    }

    public function updateBookSoldStatus(Book $book)
    {
        $book->is_sold = !$book->is_sold;
        $book->update();

        return $book;
    }

    public function uploadBookCoverPhoto(Request $request, Book $book)
    {
        // check cover photo exist on request
        if (!$request->hasFile('cover_photo')) {
            throw new Exception('Cover Photo Not found');
        }

        // upload photo to the public/uploads folder
        $fileName = $this->getFileName($request->file('cover_photo'));
        $request->file('cover_photo')->move('uploads/', $fileName);

        $book->cover_photo = $fileName;
        $book->update();

        return $book;
    }

    private  function getFileName($file)
    {
        // for uniqe image name
        $rand = substr(uniqid('', true), -5);
        $fileName = time() . '_' . $rand . '.' . $file->getClientOriginalExtension();
        // end for uniqe image name
        if (isset($name)) {
            $fileName = $name . '.' . $file->getClientOriginalExtension();
        }

        return $fileName;
    }
}
