<?php

namespace App\Providers;

use App\Repositories\BookRepository;
use App\Repositories\IBookRepository;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        // injected book repository
        $this->app->singleton(IBookRepository::class, function ($app) {
            return new BookRepository();
        });
    }
}
