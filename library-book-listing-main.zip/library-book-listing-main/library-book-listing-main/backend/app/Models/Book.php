<?php

namespace App\Models;

use App\Traits\CommonScopes;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    // use some common scope
    use CommonScopes;

    // accessor for cover 
    // get cover photo with full server url
    public function getCoverPhotoAttribute()
    {
        $coverPhoto = $this->attributes['cover_photo'];
        if (isset($coverPhoto) && file_exists("uploads/$coverPhoto")) {
            return url() . "/uploads/$coverPhoto";
        }
        return url() . "/no_image.jpg";
    }
}
