<?php

namespace App\Traits;

trait CommonScopes
{
  public function scopeSold($query)
  {
    return $query->where('is_sold', 1);
  }

  public function scopeDescending($query, $field = null)
  {
    if ($field) {
      return $query->orderBy($field, 'desc');
    }
    return $query->orderBy('created_at', 'desc');
  }

  public function scopeAscending($query, $field = null)
  {
    if ($field) {
      return $query->orderBy($field, 'asc');
    }
    return $query->orderBy('created_at', 'asc');
  }
}
