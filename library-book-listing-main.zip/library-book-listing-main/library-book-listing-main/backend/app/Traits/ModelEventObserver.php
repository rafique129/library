<?php

namespace App\Traits;


trait ModelEventObserver
{

    public static function boot()
    {
        parent::boot();


        static::creating(function ($model) {
            $model->created_by = auth()->id() ?? null;
            $model->updated_by = auth()->id() ?? null;
        });

        static::updating(function ($model) {
            $model->created_by = auth()->id() ?? null;
            $model->updated_by = auth()->id() ?? null;
        });
    }
}
