<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

abstract class ApiController extends Controller
{
    public function withError($message, $code = 200)
    {
        $data = [
            'error' => $message,
            'code' => $code
        ];
        return response()->json($data, $code);
    }

    public function withSuccess($data, $code = 200)
    {
        return response()->json($data, $code);
    }
}
