<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Repositories\BookRepository;
use Illuminate\Http\Request;

class BookController extends ApiController
{
    private $repository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(BookRepository $repository)
    {
        $this->repository = $repository;
    }

    public function index()
    {
        try {
            $response = $this->repository->getAllBooks();

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }

    public function store(Request $request)
    {
        // validation title, code and isbn number
        $this->validate($request, [
            'title' => 'required',
            'code' => 'unique:books',
            'isbn_number' => 'unique:books',
        ]);

        try {
            // save book using boo repository
            $response = $this->repository->createNewBook($request);

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }

    public function update($bookId, Request $request)
    {
        // find book by book id.
        $book = Book::findOrFail($bookId);

        // validate request data
        $this->validate($request, [
            'title' => 'required',
            'code' => 'unique:books,code,' . $book->id,
            'isbn_number' => 'unique:books,isbn_number,' . $book->id,
        ]);

        try {
            // update book using book repository
            $response = $this->repository->updateBook($request, $book);

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }

    public function destroy($bookId)
    {
        // find book by book id.
        $book = Book::findOrFail($bookId);

        try {
            // delete book using book repository
            $response = $this->repository->deleteBook($book);

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }

    public function updateBookSellStatus($bookId, Request $request)
    {
        // find book by book id.
        $book = Book::findOrFail($bookId);

        try {
            // update book using book repository
            $response = $this->repository->updateBookSoldStatus($book);

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }



    public function uploadBookCoverPhoto($bookId, Request $request)
    {

        // find book by book id.
        $book = Book::findOrFail($bookId);
        try {
            // update book using book repository
            $response = $this->repository->uploadBookCoverPhoto($request, $book);

            if ($response) {
                return $this->withSuccess($response, 200);
            } else {
                return $this->withError("Something went wrong!", 400);
            }
        } catch (\Throwable $th) {
            return $this->withError($th->getMessage(), 400);
        }
    }
}
