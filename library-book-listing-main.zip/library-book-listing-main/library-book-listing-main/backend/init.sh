install_packages unzip git
composer install
php artisan migrate